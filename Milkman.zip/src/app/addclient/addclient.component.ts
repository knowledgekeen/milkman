import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';

@Component({
  selector: 'app-addclient',
  templateUrl: './addclient.component.html',
  styleUrls: ['./addclient.component.css']
})
export class AddclientComponent implements OnInit {
  cno: string = null;
  cno1: string = null;
  fname: string = null;
  cperson: string = null;
  usertype: string = '1';
  address: string = null;
  additionalinfo: string = null;
  msgtext: string = null;
  msgclass: string = null;

  constructor(private _rest: RestService) { }

  ngOnInit(): void {
  }

  addClient() {
    let tmpobj = {
      fname: this.fname,
      cno: this.cno,
      ctype: parseInt(this.usertype),
      cperson: this.cperson,
      cno1: this.cno1,
      address: this.address,
      addinfo: this.additionalinfo,
    }
    console.log(tmpobj);

    let clienttype = (this.usertype == "1") ? "Supplier" : "Customer";
    this._rest.postData("client.php", "addClient", tmpobj).subscribe(Response => {
      this.msgtext = clienttype + " added successfully";
      this.msgclass = "success";
      this.timer();
    }, error => {
      console.log(error);
      this.msgtext = clienttype + " addition failed";
      this.msgclass = "danger";
      this.timer();
    });
  }

  timer() {
    let _this = this;
    setTimeout(function () {
      _this.msgtext = null;
      _this.msgclass = null;
    }, 2000);
  }
}
