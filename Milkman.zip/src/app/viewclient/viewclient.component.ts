import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewclient',
  templateUrl: './viewclient.component.html',
  styleUrls: ['./viewclient.component.css']
})
export class ViewclientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
